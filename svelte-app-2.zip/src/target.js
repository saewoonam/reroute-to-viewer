import { writable } from 'svelte/store';

export const target = writable("");