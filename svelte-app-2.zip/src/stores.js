import { writable } from 'svelte/store';

export const render_list = writable([]);