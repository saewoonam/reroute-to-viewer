<script>
	import Folder from './Folder.svelte';
  import tree from './tree.json'
	import { render_list } from './stores.js';
	// console.log(tree)
  tree.name='.'
	$: {
			if ($render_list.length > 0) {
				console.log($render_list)
				let github_repo = 'saewoonam/sc-current-source-hw'
				let branch_name = 'main'
				let prefix = "https://raw.githubusercontent.com/"+github_repo;
				prefix += "/"+branch_name+"/"
				// build src for iframe
				let kicad_list = encodeURIComponent($render_list.map(a => prefix+a.path).join('\n'))
				let src_url = "https://saewoonam.github.io/kicad-utils/viewer.html?url="+kicad_list;
				console.log('src_url', src_url);
				const link = document.createElement('a');
				link.href = src_url
				document.body.appendChild(link)
				link.dispatchEvent(new MouseEvent('click'))
			}
	}
</script>

<Folder {...tree}/>
<p>
	render_list: {JSON.stringify($render_list)}
</p>